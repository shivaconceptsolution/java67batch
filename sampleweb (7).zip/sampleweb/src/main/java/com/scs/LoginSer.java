package com.scs;

import java.io.IOException;

import javax.print.attribute.standard.DateTimeAtCompleted;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;
/**
 * Servlet implementation class LoginSer
 */
@WebServlet("/LoginSer")
public class LoginSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/feeddb","root","");
		Statement st = conn.createStatement();
		ResultSet res = st.executeQuery("select * from admin where username='"+request.getParameter("txtuser")+"' and password='"+request.getParameter("txtpass")+"'");
		if(res.next())
		{
			if(request.getParameter("chk")!=null)
			{
				Cookie objUser = new Cookie("cuser1",request.getParameter("txtuser"));
				//objUser.setMaxAge(10000);
				response.addCookie(objUser);
				Cookie objPass = new Cookie("cpass1",request.getParameter("txtpass"));
				//objPass.setMaxAge(10000);
				response.addCookie(objPass);
				
			}
			HttpSession ref = request.getSession();
			ref.setAttribute("adminsession",request.getParameter("txtuser"));

		   response.sendRedirect("viewreg.jsp");
		}
		else
		{
			response.sendRedirect("login.jsp?q=invalid userid and password");
		}
		}
		catch(Exception ex)
		{
			
		}
	}

}
