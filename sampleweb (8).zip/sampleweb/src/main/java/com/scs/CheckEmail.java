package com.scs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CheckEmail
 */
@WebServlet("/CheckEmail")
public class CheckEmail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckEmail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = "abcd@gmail.c";
		 int atpos = email.indexOf("@");
	    int dotpos = email.lastIndexOf(".");
	
	    PrintWriter out = response.getWriter();
	    if(atpos==-1 || dotpos == -1 || atpos>dotpos || dotpos==email.length()-1)
	    {
	    	out.write("Invalid Email Id");
	    }
	    else
	    {
	    	out.write("Valid email");
	    }
	    
	    
	}

}
